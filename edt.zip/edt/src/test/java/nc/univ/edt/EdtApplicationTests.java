package nc.univ.edt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdtApplicationTests {

	@Test
	void contextLoads() {
	}

}
